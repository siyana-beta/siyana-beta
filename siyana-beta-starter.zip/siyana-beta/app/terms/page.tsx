export default function Terms(){return <main className="page"><div className="wrap"><h1>Terms</h1><p>SIYANA Beta is a test product and does not provide medical diagnosis.</p></div></main>}
