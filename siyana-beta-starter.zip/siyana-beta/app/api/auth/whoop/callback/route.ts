import { NextRequest, NextResponse } from 'next/server';
export async function GET(req:NextRequest){
 const code=req.nextUrl.searchParams.get('code');
 if(!code){return NextResponse.redirect(new URL('/dashboard?whoop=no_code',req.url));}
 // MVP placeholder: token exchange will be added after WHOOP_CLIENT_SECRET is set.
 return NextResponse.redirect(new URL('/dashboard?whoop=connected_demo',req.url));
}
