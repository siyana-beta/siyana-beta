import { NextResponse } from 'next/server';
export async function GET(){
 const clientId=process.env.WHOOP_CLIENT_ID;
 const redirect=process.env.WHOOP_REDIRECT_URI || 'https://siyana-beta.vercel.app/api/auth/whoop/callback';
 if(!clientId){return NextResponse.redirect(new URL('/dashboard?whoop=missing_client_id','https://siyana-beta.vercel.app'));}
 const scopes=['read:profile','read:recovery','read:cycles','read:sleep','read:workout','read:body_measurement'].join(' ');
 const url=`https://api.prod.whoop.com/oauth/oauth2/auth?response_type=code&client_id=${encodeURIComponent(clientId)}&redirect_uri=${encodeURIComponent(redirect)}&scope=${encodeURIComponent(scopes)}&state=siyana-beta`;
 return NextResponse.redirect(url);
}
